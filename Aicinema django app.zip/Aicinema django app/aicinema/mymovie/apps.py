from django.apps import AppConfig


class MymovieConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mymovie'
